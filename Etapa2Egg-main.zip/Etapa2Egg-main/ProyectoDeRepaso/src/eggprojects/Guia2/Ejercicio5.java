package eggprojects.Guia2;
//Escribir un programa que lea un número entero por teclado
//y muestre por pantalla el doble, el triple y la raíz cuadrada de ese número. 

import java.util.Scanner;

//Nota: investigar la función Math.sqrt().

public class Ejercicio5 {

}