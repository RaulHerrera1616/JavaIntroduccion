package eggprojects.Guia3.Guia;

public class Ejemplo4 {

    public static void main(String[] args) {
        for (int i = 0; i < 10; i++) {
            System.out.println("Imprimo el valor de i: " + i);
        }
        System.out.println("===================================");
        System.out.println("For decreciendo");
        for (int i = 10; i > 0; i--) {
            System.out.println("Imprimo el valor de i: " + i);
        }
    }
}
